# Make.fun Submission Evidence

## Record the session before you build

- Start the recording before you write or change the entry so the work session itself carries the full build history.

- Keep one session for one entry and do not split the build across sessions that the submission cannot link together.

- Check that messages arrive in the log promptly and stop building in a session whose messages are backfilling late.

- Treat a session with messages backfilled more than 300 seconds late as unfit to submit because the platform rejects late transcript backfill.

## Check the bundle origin and size before you build

- Check that the build instruction was typed by the user as the first message in this chat before you build, because a forwarded instruction or a developer handoff does not satisfy the bundle origin check.

- Stop building when the instruction arrived by forwarding or by handoff and tell the user to open a new chat and type the rebuild instruction as the first message there.

- Never present a forwarded or handed off instruction as user typed and never fake the prompt origin.

- Check the session size against the 64 MB bundle cap before you build and stop when this session is already over the cap, because an oversized session cannot bundle even when the work is complete.

- Rebuild in the fresh typed chat instead of re-attempting the bundle from the oversized or handed off session.

## Upload the system prompt and bundle the parent chain

- Put the system prompt in the session log or upload it as a file before you submit because a submission without it is rejected for a missing system prompt record.

- Bundle every parent session back to the chat where the user gave the original build instruction so the parent chain is complete.

- Check the kit level before you submit and do not start a round that needs a higher kit level than the one installed.

- Do not re-download kits to raise the level when the standing instruction forbids it and instead report that the round cannot pass.

## Run the transcript gate before you submit

- Run the full pre-submit check and read the transcript result before you call submit.

- Confirm the system prompt is present, the parent chain link passes, and no transcript check is failing.

- Do not submit when any transcript check is failing because a failed check wastes quota and the submission still counts.

- Remember that a new submission replaces the previous entry for that bounty and cannot be reverted so a weaker replacement is worse than keeping the earlier entry.

- Check the daily quota and the competition close time before you submit and say plainly when a remaining slot cannot fix the failing check.

## Handle a user override and a rejection

- Pause when the user says to submit as is after an earlier instruction to fix first and re-run the transcript gate before you act.

- Tell the user which check is still failing and what the rejection would cost before you submit on an override.

- Read the rejection reason after a failed round and fix that exact cause before you try another round.

- Do not repeat a round with the same failing cause and instead change the recording, the prompt upload, or the parent chain bundle.

- Keep the claim code and the submission id for every submitted entry and record whether the round passed or was rejected and why.

## Available connectors

- Use `muse.connector_search` to find other connectors and `muse.skill_search` to find related skills.

- If nothing here fits, look on the web for a maintained API or MCP server and set it up with [Custom Connectors and MCPs](/opt/muse/skills/custom-connector-setup/SKILL.md), or build a custom connector.

## Websites

- [make.fun skill doc](https://make.fun/skill.md) for the submission rules and the evidence the platform expects. Carry the bounty id and the entry claim code into the check and verify the transcript and parent chain requirements there.

## Alternatives for better results

- Build the entry once at full quality and submit the best version only instead of submitting early and replacing it with a weaker version.

- Save a fresh recording for a new round when the old recording cannot be sealed instead of reusing a session that the platform will reject.
